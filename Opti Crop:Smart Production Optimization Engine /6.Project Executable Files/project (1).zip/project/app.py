import numpy as np
from flask import Flask, request, render_template
import pickle

app = Flask(__name__, template_folder='templates')

# Load the model (assuming model.pkl is in the same directory)
try:
  model = pickle.load(open('model.pkl', 'rb'))
  print("Model loaded successfully!")
except FileNotFoundError:
  print("Error: Model file 'model.pkl' not found!")
  exit(1)  # Exit the program if model is not found

@app.route('/')
def home():
  return render_template('home.html')

@app.route('/about')
def about():
  return render_template("about.html")

@app.route("/findyourcrop")
def findyourcrop():
  return render_template('findyourcrop.html')

@app.route('/predict', methods=['POST'])
def predict():
  # Extract form data
  try:
    int_features = [float(x) for x in request.form.values()]
  except ValueError:
    print("Error: Invalid data type in form submission!")
    return render_template("findyourcrop.html", prediction_text="Please enter valid numerical values.")

  # Prepare features for prediction
  features = [np.array(int_features)]

  # Make prediction
  prediction = model.predict(features)
  print(prediction)  # Print for debugging

  # Extract output (assuming single value prediction)
  output = prediction[0]

  # Render template with prediction
  return render_template("findyourcrop.html", prediction_text='Best crop for given conditions is {}'.format(output))

if __name__ == '__main__':
  app.run(debug=True)  # Run the Flask app in debug mode
